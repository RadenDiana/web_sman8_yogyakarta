<?php

use Illuminate\Support\Facades\Route;

Route::view('/', 'guest.home')->name('home');
Route::view('/tentang', 'guest.tentang.index')->name('tentang');
Route::view('/guru', 'guest.guru.index')->name('guest.guru');
Route::view('/pengumuman', 'guest.pengumuman.index')->name('guest.pengumuman');
Route::view('/pengumuman/{id}', 'guest.pengumuman.show')->name('guest.pengumuman.show');
Route::view('/prestasi', 'guest.prestasi.index')->name('guest.prestasi');
Route::view('/prestasi/{id}', 'guest.prestasi.show')->name('guest.prestasi.show');
Route::view('/galeri', 'guest.galeri.index')->name('guest.galeri');

Route::view('/login', 'auth.login')->name('login');

/*
|--------------------------------------------------------------------------
| Frontend demo admin
|--------------------------------------------------------------------------
| Belum memakai database/auth. Semua tombol CRUD adalah UI frontend.
| Nanti route ini dapat diganti dengan Controller + middleware auth.
*/
Route::prefix('admin')->name('admin.')->group(function () {
    Route::view('/', 'admin.dashboard')->name('dashboard');

    foreach ([
        'guru', 'siswa', 'ekstrakurikuler', 'pengumuman',
        'prestasi', 'galeri', 'akun'
    ] as $resource) {
        Route::view("/{$resource}", "admin.{$resource}.index")->name("{$resource}.index");
        Route::view("/{$resource}/create", "admin.{$resource}.create")->name("{$resource}.create");
        Route::view("/{$resource}/edit", "admin.{$resource}.edit")->name("{$resource}.edit");
    }

    Route::view('/guru/show', 'admin.guru.show')->name('guru.show');
    Route::view('/siswa/show', 'admin.siswa.show')->name('siswa.show');
});
