document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('[data-nav-toggle]');
    const siteNav = document.querySelector('#siteNav');
    navToggle?.addEventListener('click', () => siteNav?.classList.toggle('open'));

    document.querySelectorAll('[data-sidebar-toggle]').forEach(el => {
        el.addEventListener('click', () => {
            document.querySelector('#adminSidebar')?.classList.toggle('open');
            document.querySelector('.admin-overlay')?.classList.toggle('open');
        });
    });

    document.querySelectorAll('[data-delete]').forEach(btn => {
        btn.addEventListener('click', () => {
            if (confirm('Hapus data ini? (Frontend demo)')) {
                const row = btn.closest('tr, .extra-card, .gallery-admin-card');
                row?.remove();
            }
        });
    });

    document.querySelectorAll('[data-gallery-item]').forEach(item => {
        item.addEventListener('click', () => {
            const backdrop = document.querySelector('[data-modal-backdrop]');
            const content = document.querySelector('[data-modal-content]');
            if (!backdrop || !content) return;
            content.innerHTML = `<h2>${item.dataset.galleryItem}</h2><div class="gallery-photo" style="min-height:300px"><span>${item.dataset.galleryItem}</span></div>`;
            backdrop.hidden = false;
        });
    });

    document.querySelector('[data-modal-close]')?.addEventListener('click', () => {
        document.querySelector('[data-modal-backdrop]').hidden = true;
    });

    document.querySelector('[data-modal-backdrop]')?.addEventListener('click', e => {
        if (e.target === e.currentTarget) e.currentTarget.hidden = true;
    });
});

window.demoSubmit = function(event, message) {
    event.preventDefault();
    alert(message + '\n\nIni masih frontend demo. Data belum masuk database.');
};

window.demoLogin = function(event) {
    event.preventDefault();
    alert('Login frontend demo berhasil.');
    window.location.href = '/admin';
};
