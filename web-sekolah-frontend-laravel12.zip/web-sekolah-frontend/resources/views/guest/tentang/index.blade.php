@extends('layouts.guest')
@section('content')
<div class="page-hero"><div class="container"><span class="eyebrow blue">TENTANG SEKOLAH</span><h1>SMA Negeri 8 Yogyakarta</h1><p>Mengenal lebih dekat sekolah, visi, misi, dan tujuan pendidikan kami.</p></div></div>
<section class="section container prose-page">
    <h2>Deskripsi Sekolah</h2>
    <p>SMA Negeri 8 Yogyakarta adalah satuan pendidikan yang berkomitmen memberikan pembelajaran berkualitas dan membentuk peserta didik yang cerdas, berkarakter, mandiri, serta berwawasan luas.</p>
    <div class="two-col">
        <div class="info-card"><span class="eyebrow blue">VISI</span><h3>Unggul dalam prestasi dan berkarakter dalam kehidupan.</h3></div>
        <div class="info-card"><span class="eyebrow blue">MISI</span><ul><li>Menyelenggarakan pembelajaran yang aktif dan inovatif.</li><li>Mengembangkan potensi akademik dan nonakademik siswa.</li><li>Menumbuhkan karakter, kedisiplinan, dan kepedulian.</li></ul></div>
    </div>
    <h2>Tujuan Sekolah</h2>
    <ol class="number-list"><li>Meningkatkan prestasi akademik dan nonakademik.</li><li>Membentuk lulusan yang berkarakter dan siap melanjutkan pendidikan.</li><li>Membangun budaya sekolah yang aman, sehat, dan inklusif.</li></ol>
</section>
@endsection
