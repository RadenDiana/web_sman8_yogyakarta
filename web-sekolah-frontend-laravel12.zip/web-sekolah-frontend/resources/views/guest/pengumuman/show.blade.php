@extends('layouts.guest')
@section('content')
<div class="page-hero"><div class="container"><span class="eyebrow blue">PENGUMUMAN</span><h1>JADWAL DCCB 15 JULI 2026</h1><p>15 Juli 2026 · Dipublikasikan</p></div></div>
<section class="section container article-page">
    <div class="article-cover">JADWAL DCCB 2026</div>
    <h2>JADWAL DCCB 15 JULI 2026</h2>
    <p class="muted">15 Juli 2026</p>
    <p>Informasi jadwal kegiatan sekolah yang perlu diperhatikan oleh seluruh siswa dan warga sekolah.</p>
    <blockquote>“Mari jadikan setiap kegiatan sebagai langkah menuju versi terbaik diri kita!”</blockquote>
    <a href="{{ route('guest.pengumuman') }}" class="btn outline"><i class="bi bi-arrow-left"></i> Kembali</a>
</section>
@endsection
