@extends('layouts.guest')
@section('content')
<div class="page-hero"><div class="container"><span class="eyebrow blue">INFORMASI</span><h1>Semua Pengumuman</h1><p>Informasi dan pengumuman terbaru sekolah.</p></div></div>
<section class="section container">
    <div class="search-row"><div class="search-bar"><i class="bi bi-search"></i><input placeholder="Cari pengumuman..."></div><select><option>Terbaru</option><option>Terlama</option></select></div>
    <div class="public-list">
        @foreach(['JADWAL DCCB 15 JULI 2026','JADWAL DCCB 14 JULI 2026','JADWAL DCCB 13 JULI 2026','Pengumuman Seleksi SPMB 2026','Upacara Bendera SMAN 8 Yogyakarta','Rapat Orang Tua Siswa'] as $i => $item)
        <a class="public-list-card" href="{{ route('guest.pengumuman.show', $i+1) }}"><div class="announcement-img">PENGUMUMAN</div><div><small>{{ 15-$i }} Jul 2026</small><h3>{{ $item }}</h3><p>Informasi resmi sekolah untuk seluruh warga sekolah.</p></div><i class="bi bi-arrow-right"></i></a>
        @endforeach
    </div>
</section>
@endsection
