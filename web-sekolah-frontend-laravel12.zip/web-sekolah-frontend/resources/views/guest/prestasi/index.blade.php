@extends('layouts.guest')
@section('content')
<div class="page-hero"><div class="container"><span class="eyebrow blue">PRESTASI</span><h1>Prestasi Siswa</h1><p>Kumpulan prestasi dan pencapaian siswa SMA Negeri 8 Yogyakarta.</p></div></div>
<section class="section container">
    <div class="public-achievement-grid">
        @foreach(['Kompetisi Bahasa dan Sastra Bidang Panatacara','Kompetisi Bahasa dan Sastra Bidang Maca Cerkak','Kompetisi Bahasa dan Sastra Bidang ALIH AKSARA','Lomba Tingkat Nasional','Festival Seni Pelajar','Kompetisi Sains'] as $i => $item)
        <a class="public-achievement-card" href="{{ route('guest.prestasi.show', $i+1) }}"><div class="achievement-img">JUARA<br><strong>{{ $i < 3 ? 1 : 2 }}</strong></div><div><small>10 Jul 2026</small><h3>{{ $item }}</h3><p>Prestasi siswa SMA Negeri 8 Yogyakarta.</p></div></a>
        @endforeach
    </div>
</section>
@endsection
