@extends('layouts.guest')
@section('content')
<div class="page-hero"><div class="container"><span class="eyebrow blue">PRESTASI</span><h1>Kompetisi Bahasa dan Sastra</h1><p>10 Juli 2026 · Juara 1</p></div></div>
<section class="section container article-page">
    <div class="achievement-large">JUARA 1</div>
    <h2>Kompetisi Bahasa dan Sastra Bidang Panatacara</h2>
    <p class="muted">10 Juli 2026</p>
    <p>Selamat kepada siswa SMA Negeri 8 Yogyakarta yang berhasil meraih prestasi dalam kompetisi Bahasa dan Sastra.</p>
    <a href="{{ route('guest.prestasi') }}" class="btn outline"><i class="bi bi-arrow-left"></i> Kembali</a>
</section>
@endsection
