@extends('layouts.guest')
@section('content')

<section id="beranda" class="hero">
    <div class="hero-bg"></div>
    <div class="hero-content container">
        <span class="eyebrow">SMA NEGERI 8 YOGYAKARTA</span>
        <h1>Membangun Generasi<br><strong>Cerdas dan Berkarakter</strong></h1>
        <p>Sekolah yang unggul dalam prestasi, berkarakter, dan siap menghadapi masa depan.</p>
        <a href="{{ route('tentang') }}" class="btn primary">Tentang Sekolah <i class="bi bi-arrow-right"></i></a>
    </div>
    <div class="hero-stats container">
        <div><strong>42</strong><span>Jumlah Guru</span></div>
        <div><strong>863</strong><span>Jumlah Murid</span></div>
        <div><strong>A</strong><span>Akreditasi</span></div>
    </div>
</section>

<section class="section container welcome">
    <div class="section-heading">
        <div>
            <span class="eyebrow blue">SAMBUTAN KEPALA</span>
            <h2>SEKOLAH</h2>
        </div>
        <a href="{{ route('tentang') }}" class="text-link">Lihat selengkapnya <i class="bi bi-arrow-right"></i></a>
    </div>
    <div class="welcome-grid">
        <div class="principal-photo">Kepala<br>Sekolah</div>
        <div>
            <p class="lead">Assalamu'alaikum warahmatullahi wabarakatuh.</p>
            <p>Selamat datang di website resmi SMA Negeri 8 Yogyakarta. Website ini menjadi media informasi sekolah sekaligus ruang untuk memperkenalkan berbagai kegiatan, prestasi, dan layanan sekolah kepada masyarakat.</p>
            <p>Mari bersama-sama membangun lingkungan pendidikan yang positif, berprestasi, dan berkarakter.</p>
            <small>Dr. Kepala Sekolah, M.Pd.</small>
        </div>
    </div>
</section>

<section class="section dark-section news-section">
    <div class="container">
        <div class="section-heading light">
            <div><span class="eyebrow">INFORMASI TERBARU</span><h2>Berita Terbaru</h2></div>
            <a href="{{ route('guest.pengumuman') }}" class="text-link light-link">Lihat semua <i class="bi bi-arrow-right"></i></a>
        </div>
        <div class="card-grid news-grid">
            @foreach([
                ['JADWAL DCCB 15 JULI 2026','15 Jul 2026'],
                ['JADWAL DCCB 14 JULI 2026','14 Jul 2026'],
                ['Pengumuman Seleksi SPMB 2026','25 Jun 2026'],
                ['Upacara Bendera SMAN 8 Yogyakarta','18 Mei 2026'],
            ] as $news)
            <article class="news-card">
                <div class="news-thumb"><i class="bi bi-file-earmark-text"></i></div>
                <div><small>{{ $news[1] }}</small><h3>{{ $news[0] }}</h3><a href="{{ route('guest.pengumuman') }}" class="text-link">Baca selengkapnya</a></div>
            </article>
            @endforeach
        </div>
    </div>
</section>

<section id="informasi" class="section container">
    <div class="center-heading"><span class="eyebrow blue">INFORMASI</span><h2>Informasi Sekolah</h2></div>

    <div class="info-block">
        <div class="section-heading compact">
            <h3>Daftar Ekstrakurikuler</h3>
            <span class="mini-link">Lihat semua</span>
        </div>
        <div class="pill-grid">
            @foreach(['Pramuka','Petanque','Cheerleaders','Tahfiz Quran','Flag Football','Hadroh','Pencak Silat','Orkestra','Paduan Suara','KIR'] as $item)
                <div class="dark-pill">{{ $item }}</div>
            @endforeach
        </div>
    </div>

    <div class="info-block">
        <div class="section-heading compact">
            <h3>Daftar Guru</h3>
            <a href="{{ route('guest.guru') }}" class="mini-link">Lihat semua</a>
        </div>
        <div class="teacher-row">
            @foreach(['Rina Dwi Astuti','Budi Santoso','Siti Rahma','Dewi Lestari'] as $teacher)
            <div class="teacher-card">
                <div class="avatar teacher-avatar">{{ strtoupper(substr($teacher,0,1)) }}</div>
                <strong>{{ $teacher }}</strong><small>S.Pd.</small>
            </div>
            @endforeach
        </div>
    </div>

    <div class="info-block">
        <div class="section-heading compact"><h3>Data Siswa</h3><span class="mini-link">Lihat semua</span></div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>Kelas</th><th>Jumlah</th><th>L</th><th>P</th><th>Kristen</th><th>Islam</th><th>Hindu</th><th>Buddha</th></tr></thead>
                <tbody>
                    @foreach(['X F1','X F2','XI F1','XI F2','XII F1'] as $class)
                    <tr><td>{{ $class }}</td><td>36</td><td>15</td><td>21</td><td>2</td><td>31</td><td>2</td><td>1</td></tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>

    <div class="info-block">
        <div class="section-heading compact">
            <h3>Pengumuman</h3>
            <a href="{{ route('guest.pengumuman') }}" class="mini-link">Lihat semua</a>
        </div>
        <div class="announcement-grid">
            @foreach(['JADWAL DCCB 15 JULI 2026','JADWAL DCCB 14 JULI 2026','JADWAL DCCB 13 JULI 2026','Pengumuman Seleksi SPMB 2026'] as $item)
            <article class="announcement-card">
                <div class="announcement-img">PENGUMUMAN</div>
                <div><small>15 Jul 2026</small><h4>{{ $item }}</h4><p>Informasi terbaru untuk siswa dan warga sekolah.</p></div>
            </article>
            @endforeach
        </div>
    </div>
</section>

<section id="prestasi" class="section dark-section">
    <div class="container">
        <div class="section-heading light">
            <div><span class="eyebrow">PRESTASI</span><h2>Prestasi Siswa</h2></div>
            <a href="{{ route('guest.prestasi') }}" class="text-link light-link">Lihat semua <i class="bi bi-arrow-right"></i></a>
        </div>
        <div class="card-grid achievement-grid">
            @foreach(['Kompetisi Bahasa dan Sastra Bidang Panatacara','Kompetisi Bahasa dan Sastra Bidang Maca Cerkak','Kompetisi Bahasa dan Sastra Bidang ALIH AKSARA','Juara Lomba Tingkat Nasional'] as $item)
            <article class="achievement-card">
                <div class="achievement-img">JUARA<br><strong>1</strong></div>
                <div><small>10 Jul 2026</small><h3>{{ $item }}</h3><p>Prestasi siswa SMA Negeri 8 Yogyakarta.</p></div>
            </article>
            @endforeach
        </div>
    </div>
</section>

<section id="galeri" class="section container">
    <div class="section-heading"><div><span class="eyebrow blue">GALERI</span><h2>Dokumentasi Sekolah</h2></div><a href="{{ route('guest.galeri') }}" class="text-link">Lihat semua <i class="bi bi-arrow-right"></i></a></div>
    <div class="gallery-grid">
        @foreach(range(1,9) as $i)
            <div class="gallery-photo" style="--i:{{ $i }}"><span>Foto {{ $i }}</span></div>
        @endforeach
    </div>
</section>

<section id="kontak" class="section container contact-section">
    <div class="center-heading"><span class="eyebrow blue">KONTAK</span><h2>Hubungi Kami</h2></div>
    <div class="contact-card">
        <div class="map-placeholder"><i class="bi bi-geo-alt-fill"></i><span>Google Maps Sekolah</span></div>
        <div class="contact-list">
            <div><i class="bi bi-geo-alt"></i><div><strong>Alamat</strong><span>Jl. Sidobali No. 1, Yogyakarta</span></div></div>
            <div><i class="bi bi-telephone"></i><div><strong>Hubungi kami</strong><span>(0274) 123456</span></div></div>
            <div><i class="bi bi-envelope"></i><div><strong>Email kami</strong><span>info@sman8yogyakarta.sch.id</span></div></div>
        </div>
    </div>
</section>
@endsection
