@extends('layouts.guest')
@section('content')
<div class="page-hero"><div class="container"><span class="eyebrow blue">INFORMASI</span><h1>Daftar Guru</h1><p>Data tenaga pendidik SMA Negeri 8 Yogyakarta.</p></div></div>
<section class="section container">
    <div class="search-bar"><i class="bi bi-search"></i><input placeholder="Cari guru..."></div>
    <div class="public-teacher-grid">
        @foreach(['Rina Dwi Astuti','Budi Santoso','Siti Rahma','Dewi Lestari','Agus Pratama','Nina Wulandari','Fajar Hidayat','Maya Putri'] as $teacher)
        <article class="public-teacher-card"><div class="avatar teacher-avatar">{{ strtoupper(substr($teacher,0,1)) }}</div><h3>{{ $teacher }}, S.Pd.</h3><p>Guru Mata Pelajaran</p><span>Aktif</span></article>
        @endforeach
    </div>
</section>
@endsection
