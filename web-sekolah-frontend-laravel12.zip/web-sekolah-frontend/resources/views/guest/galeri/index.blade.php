@extends('layouts.guest')
@section('content')
<div class="page-hero"><div class="container"><span class="eyebrow blue">GALERI</span><h1>Galeri Sekolah</h1><p>Dokumentasi kegiatan dan momen sekolah.</p></div></div>
<section class="section container">
    <div class="gallery-grid large">
        @foreach(range(1,18) as $i)
            <button class="gallery-photo" data-gallery-item="Foto kegiatan {{ $i }}"><span>Foto {{ $i }}</span></button>
        @endforeach
    </div>
</section>
@include('components.modal')
@endsection
