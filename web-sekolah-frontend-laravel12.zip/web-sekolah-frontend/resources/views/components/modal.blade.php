<div class="modal-backdrop" data-modal-backdrop hidden>
    <div class="modal-box">
        <button class="modal-close" data-modal-close>&times;</button>
        <div data-modal-content></div>
    </div>
</div>
