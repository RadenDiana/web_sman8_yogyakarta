<header class="site-header">
    <a class="brand" href="{{ route('home') }}">
        <span class="school-logo small">S8</span>
        <span>SMA NEGERI 8 YOGYAKARTA</span>
    </a>

    <button class="nav-toggle" data-nav-toggle aria-label="Buka menu">
        <i class="bi bi-list"></i>
    </button>

    <nav class="site-nav" id="siteNav">
        <a href="{{ route('home') }}#beranda">Beranda</a>
        <a href="{{ route('home') }}#informasi">Informasi</a>
        <a href="{{ route('home') }}#prestasi">Prestasi</a>
        <a href="{{ route('home') }}#galeri">Galeri</a>
        <a href="{{ route('home') }}#kontak">Kontak</a>
        <a class="nav-login" href="{{ route('login') }}">Masuk</a>
    </nav>
</header>
