<footer class="site-footer">
    <div class="footer-inner">
        <div>
            <div class="footer-brand">
                <span class="school-logo">S8</span>
                <strong>SMA NEGERI 8 YOGYAKARTA</strong>
            </div>
            <p>SMA Negeri 8 Yogyakarta merupakan sekolah yang berkomitmen membangun generasi cerdas, berkarakter, dan berprestasi.</p>
        </div>
        <div>
            <h4>Ikuti Kami</h4>
            <div class="socials">
                <a href="#" aria-label="Instagram"><i class="bi bi-instagram"></i></a>
                <a href="#" aria-label="TikTok"><i class="bi bi-tiktok"></i></a>
                <a href="#" aria-label="YouTube"><i class="bi bi-youtube"></i></a>
                <a href="#" aria-label="LinkedIn"><i class="bi bi-linkedin"></i></a>
            </div>
        </div>
    </div>
    <div class="footer-bottom">© {{ date('Y') }} SMA Negeri 8 Yogyakarta. All Rights Reserved.</div>
</footer>
