@if(session('success'))
<div class="alert success"><i class="bi bi-check-circle"></i>{{ session('success') }}</div>
@endif
@if(session('error'))
<div class="alert danger"><i class="bi bi-exclamation-circle"></i>{{ session('error') }}</div>
@endif
