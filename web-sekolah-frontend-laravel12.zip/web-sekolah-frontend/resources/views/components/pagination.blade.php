<div class="pagination">
    <span>Menampilkan 1 sampai {{ $total ?? 8 }} data</span>
    <div class="page-buttons">
        <button class="active">1</button><button>2</button><button>3</button><button>...</button><button>8</button>
        <button><i class="bi bi-chevron-right"></i></button>
    </div>
</div>
