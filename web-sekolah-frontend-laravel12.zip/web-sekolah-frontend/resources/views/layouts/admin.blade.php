<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $title ?? 'Admin - SMA Negeri 8 Yogyakarta' }}</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="admin-body">
    <button class="mobile-sidebar-toggle" data-sidebar-toggle><i class="bi bi-list"></i></button>
    <aside class="admin-sidebar" id="adminSidebar">
        <div class="admin-profile">
            <div class="school-logo">S8</div>
            <div>
                <strong>Admin</strong>
                <small>admin_web@gmail.com</small>
            </div>
        </div>

        <nav class="admin-nav">
            <a class="{{ request()->routeIs('admin.dashboard') ? 'active' : '' }}" href="{{ route('admin.dashboard') }}">
                <i class="bi bi-grid-fill"></i><span>Dashboard</span>
            </a>
            <a class="{{ request()->routeIs('admin.guru.*') ? 'active' : '' }}" href="{{ route('admin.guru.index') }}">
                <i class="bi bi-people-fill"></i><span>Data Guru</span>
            </a>
            <a class="{{ request()->routeIs('admin.siswa.*') ? 'active' : '' }}" href="{{ route('admin.siswa.index') }}">
                <i class="bi bi-person-lines-fill"></i><span>Data Siswa</span>
            </a>
            <a class="{{ request()->routeIs('admin.ekstrakurikuler.*') ? 'active' : '' }}" href="{{ route('admin.ekstrakurikuler.index') }}">
                <i class="bi bi-people"></i><span>Ekstrakurikuler</span>
            </a>
            <a class="{{ request()->routeIs('admin.pengumuman.*') ? 'active' : '' }}" href="{{ route('admin.pengumuman.index') }}">
                <i class="bi bi-file-earmark-text-fill"></i><span>Pengumuman</span>
            </a>
            <a class="{{ request()->routeIs('admin.prestasi.*') ? 'active' : '' }}" href="{{ route('admin.prestasi.index') }}">
                <i class="bi bi-star-fill"></i><span>Prestasi</span>
            </a>
            <a class="{{ request()->routeIs('admin.galeri.*') ? 'active' : '' }}" href="{{ route('admin.galeri.index') }}">
                <i class="bi bi-image-fill"></i><span>Galeri</span>
            </a>
            <a class="{{ request()->routeIs('admin.akun.*') ? 'active' : '' }}" href="{{ route('admin.akun.index') }}">
                <i class="bi bi-person-gear"></i><span>Akun</span>
            </a>
        </nav>

        <a href="{{ route('home') }}" class="sidebar-logout">
            <i class="bi bi-arrow-left"></i> Keluar
        </a>
    </aside>

    <main class="admin-main">
        <div class="admin-overlay" data-sidebar-toggle></div>
        @yield('content')
    </main>
</body>
</html>
