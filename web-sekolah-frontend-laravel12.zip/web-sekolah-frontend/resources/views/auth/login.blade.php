@extends('layouts.auth')
@section('content')
<div class="login-wrap">
    <div class="login-brand"><span class="school-logo big">S8</span><h1>SMA NEGERI 8 YOGYAKARTA</h1></div>
    <form class="login-card" onsubmit="demoLogin(event)">
        <label><i class="bi bi-envelope"></i><input type="email" placeholder="admin_web@gmail.com" required></label>
        <label><i class="bi bi-lock"></i><input type="password" placeholder="••••••••••••" required></label>
        <p class="help">Butuh Bantuan? <a href="#kontak">Hubungi Admin</a></p>
        <button class="login-button">MASUK</button>
        <a href="{{ route('home') }}" class="back-home"><i class="bi bi-arrow-left"></i> Kembali ke beranda</a>
    </form>
</div>
@endsection
