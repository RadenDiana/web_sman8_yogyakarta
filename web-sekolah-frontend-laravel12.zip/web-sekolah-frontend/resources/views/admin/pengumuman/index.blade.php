@extends('layouts.admin')
@section('content')
<div class="admin-page-head"><div><h1>Pengumuman</h1><p>Dashboard / Pengumuman</p></div><a href="{{ route('admin.pengumuman.create') }}" class="btn primary">+ Pengumuman</a></div>
<div class="toolbar"><div class="search-bar"><i class="bi bi-search"></i><input placeholder="Cari pengumuman..."></div><select><option>Urutan berdasarkan</option><option>Terbaru</option><option>Terlama</option></select></div>
<div class="admin-card table-card"><table><thead><tr><th>Judul</th><th>Tanggal</th><th>Status</th><th>Aksi</th></tr></thead><tbody>
@foreach(['JADWAL DCCB 15 JULI 2026','JADWAL DCCB 14 JULI 2026','JADWAL DCCB 13 JULI 2026','Pengumuman Seleksi SPMB 2026','Upacara Bendera SMAN 8 Yogyakarta'] as $i => $item)
<tr><td>{{ $item }}</td><td>{{ 15-$i }} Jul 2026</td><td><span class="badge success">Publish</span></td><td class="actions"><button data-detail="pengumuman"><i class="bi bi-eye"></i></button><a href="{{ route('admin.pengumuman.edit') }}"><i class="bi bi-pencil"></i></a><button data-delete><i class="bi bi-trash"></i></button></td></tr>
@endforeach
</tbody></table>@include('components.pagination',['total'=>42])</div>
@endsection
