@extends('layouts.admin')
@section('content')
<div class="admin-page-head"><div><h1>Galeri</h1><p>Dashboard / Galeri</p></div><a href="{{ route('admin.galeri.create') }}" class="btn primary">+ Galeri</a></div>
<div class="toolbar"><div class="search-bar"><i class="bi bi-search"></i><input placeholder="Cari galeri..."></div><select><option>Urutan berdasarkan</option><option>Terbaru</option><option>Terlama</option></select></div>
<div class="gallery-admin-grid">
@foreach(range(1,8) as $i)
<article class="gallery-admin-card"><div class="gallery-photo"><span>Foto {{ $i }}</span></div><div class="gallery-meta"><h3>Kokurikuler Keraton Yogyakarta</h3><small>04 Mei 2026</small><span class="badge success">Publish</span></div><div class="actions"><a href="{{ route('admin.galeri.edit') }}"><i class="bi bi-pencil"></i></a><button data-delete><i class="bi bi-trash"></i></button></div></article>
@endforeach
</div>
@include('components.pagination',['total'=>42])
@endsection
