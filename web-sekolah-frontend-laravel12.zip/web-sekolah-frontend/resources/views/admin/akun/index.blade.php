@extends('layouts.admin')
@section('content')
<div class="admin-page-head"><div><h1>Akun</h1><p>Dashboard / Akun</p></div><a href="{{ route('admin.akun.create') }}" class="btn primary">+ Akun</a></div>
<div class="count-label">Total Akun : <strong>2</strong></div>
<div class="account-grid">
@foreach(['Admin Website','Operator Website'] as $account)
<div class="account-card"><div class="account-icon"><i class="bi bi-person-circle"></i></div><div><h3>{{ $account }}</h3><p>admin_web@gmail.com</p></div><div class="actions"><a href="{{ route('admin.akun.edit') }}"><i class="bi bi-pencil"></i></a><button data-delete><i class="bi bi-trash"></i></button></div></div>
@endforeach
</div>
@include('components.pagination',['total'=>2])
@endsection
