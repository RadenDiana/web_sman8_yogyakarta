@extends('layouts.admin')
@section('content')
<div class="admin-page-head"><div><h1>Edit Akun</h1><p>Dashboard / Akun</p></div></div>
<form class="admin-card form-card narrow-form" onsubmit="demoSubmit(event,'Akun berhasil disimpan!')">
<label>Username<input required></label><label>Email<input type="email" required></label><label>Password<input type="password" required></label>
<div class="form-actions"><a href="{{ route('admin.akun.index') }}" class="btn outline">Batal</a><button class="btn primary">Simpan</button></div>
</form>
@endsection
