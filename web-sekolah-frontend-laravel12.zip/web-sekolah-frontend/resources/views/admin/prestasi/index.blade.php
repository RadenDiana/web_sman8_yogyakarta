@extends('layouts.admin')
@section('content')
<div class="admin-page-head"><div><h1>Prestasi</h1><p>Dashboard / Prestasi</p></div><a href="{{ route('admin.prestasi.create') }}" class="btn primary">+ Prestasi</a></div>
<div class="toolbar"><div class="search-bar"><i class="bi bi-search"></i><input placeholder="Cari prestasi..."></div><select><option>Urutan berdasarkan</option><option>Terbaru</option><option>Terlama</option></select></div>
<div class="achievement-admin-list">
@foreach(['Kompetisi Bahasa dan Sastra Bidang Panatacara','Kompetisi Bahasa dan Sastra Bidang Maca Cerkak','Kompetisi Bahasa dan Sastra Bidang ALIH AKSARA','Kompetisi Sains Nasional'] as $item)
<article class="achievement-admin-card"><div class="achievement-img">JUARA<br><strong>1</strong></div><div class="grow"><h3>{{ $item }}</h3><small>10 Jul 2026</small><span class="badge success">Publish</span></div><div class="actions"><button><i class="bi bi-eye"></i></button><a href="{{ route('admin.prestasi.edit') }}"><i class="bi bi-pencil"></i></a><button data-delete><i class="bi bi-trash"></i></button></div></article>
@endforeach
</div>
@include('components.pagination',['total'=>15])
@endsection
