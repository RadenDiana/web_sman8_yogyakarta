@extends('layouts.admin')
@section('content')
<div class="admin-page-head"><div><h1>{{ $mode ?? 'Tambah' }} Prestasi</h1><p>Dashboard / Prestasi</p></div></div>
<form class="admin-card form-card" onsubmit="demoSubmit(event,'Prestasi berhasil disimpan!')">
<div class="form-grid"><label>Judul<input required></label><label>Tanggal<input type="date" required></label><label>Status<select><option>Draft</option><option>Publish</option></select></label><label>Foto<input type="file" accept="image/*"></label></div>
<label>Deskripsi<textarea rows="8" required></textarea></label>
<div class="form-actions"><a href="{{ route('admin.prestasi.index') }}" class="btn outline">Batal</a><button class="btn primary">Simpan</button></div>
</form>
@endsection
