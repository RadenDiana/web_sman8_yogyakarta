@extends('layouts.admin')
@section('content')
<div class="admin-page-head"><div><h1>Data Guru</h1><p>Dashboard / Data Guru</p></div><a href="{{ route('admin.guru.create') }}" class="btn primary">+ Tambah Guru</a></div>
<div class="toolbar"><div class="search-bar"><i class="bi bi-search"></i><input placeholder="Cari guru..."></div><select><option>Semua Mata Pelajaran</option><option>Ekonomi</option><option>Matematika</option></select></div>
<div class="admin-card table-card"><table><thead><tr><th>Guru</th><th>NIP</th><th>Mapel</th><th>Status</th><th>Aksi</th></tr></thead><tbody>
@foreach(['RINA DWI ASTUTI, S.Pd.','BUDI SANTOSO, S.Pd.','SITI RAHMA, S.Pd.','DEWI LESTARI, S.Pd.','AGUS PRATAMA, S.Pd.'] as $name)
<tr><td>{{ $name }}</td><td>123456789011121314</td><td>Ekonomi</td><td><span class="badge success">Aktif</span></td><td class="actions"><a href="{{ route('admin.guru.show') }}"><i class="bi bi-eye"></i></a><a href="{{ route('admin.guru.edit') }}"><i class="bi bi-pencil"></i></a><button data-delete><i class="bi bi-trash"></i></button></td></tr>
@endforeach
</tbody></table>@include('components.pagination',['total'=>42])</div>
@endsection
