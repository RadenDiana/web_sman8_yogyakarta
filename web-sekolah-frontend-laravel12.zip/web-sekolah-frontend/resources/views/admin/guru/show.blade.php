@extends('layouts.admin')
@section('content')
<div class="admin-page-head"><div><h1>Detail Guru</h1><p>Dashboard / Data Guru / Detail</p></div></div>
<div class="detail-card admin-card"><div class="detail-photo">FOTO<br>GURU</div><div class="detail-info">
@foreach([['Nama','RINA DWI ASTUTI, S.Pd.'],['NIP','12345678'],['Mata Pelajaran','Ekonomi'],['Jenis kelamin','Perempuan'],['Agama','Kristen'],['Tempat, Tgl lahir','Bogor, 12 Agustus 1990'],['Email','guru_ekonomi@gmail.com'],['Telepon','081234567890'],['Alamat','Jl. Bojong kidul, RT.06/RW.02']] as $row)<div><span>{{ $row[0] }}</span><strong>{{ $row[1] }}</strong></div>@endforeach
</div><div class="detail-actions"><a href="{{ route('admin.guru.edit') }}" class="btn primary">Edit</a><a href="{{ route('admin.guru.index') }}" class="btn outline">Tutup</a></div></div>
@endsection
