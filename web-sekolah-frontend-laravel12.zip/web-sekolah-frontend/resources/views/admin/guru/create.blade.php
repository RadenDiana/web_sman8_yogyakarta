@extends('layouts.admin')
@section('content')
<div class="admin-page-head"><div><h1>{{ $mode ?? 'Tambah' }} Guru</h1><p>Dashboard / Data Guru / {{ $mode ?? 'Tambah' }}</p></div></div>
<form class="admin-card form-card" onsubmit="demoSubmit(event,'Data guru berhasil disimpan!')">
<div class="form-grid">
@foreach([['Nama Lengkap','text'],['NIP','text'],['Mata Pelajaran','text'],['Email','email'],['Telepon','text'],['Tempat Lahir','text'],['Tanggal Lahir','date'],['Alamat','text']] as $field)
<label>{{ $field[0] }}<input type="{{ $field[1] }}" required></label>
@endforeach
<label>Jenis Kelamin<select><option>Perempuan</option><option>Laki-laki</option></select></label>
<label>Agama<select><option>Islam</option><option>Kristen</option><option>Katolik</option><option>Hindu</option><option>Buddha</option></select></label>
<label>Foto Guru<input type="file" accept="image/*"></label>
</div><div class="form-actions"><a href="{{ route('admin.guru.index') }}" class="btn outline">Batal</a><button class="btn primary">Simpan</button></div>
</form>
@endsection
