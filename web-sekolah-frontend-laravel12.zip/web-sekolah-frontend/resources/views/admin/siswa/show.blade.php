@extends('layouts.admin')
@section('content')
<div class="admin-page-head"><div><h1>Detail Siswa</h1><p>Dashboard / Data Siswa / Detail</p></div></div>
<div class="detail-card admin-card"><div class="detail-photo student">FOTO<br>SISWA</div><div class="detail-info">
@foreach([['Nama','RADEN MARDIANA'],['NIS','12345678910'],['Kelas','XII F 1'],['Jenis kelamin','Perempuan'],['Agama','Islam'],['Tempat, Tgl lahir','Bogor, 17 Maret 2008'],['Alamat','Jl. Bojong Kidul, RT.06/RW.02']] as $row)<div><span>{{ $row[0] }}</span><strong>{{ $row[1] }}</strong></div>@endforeach
</div><div class="detail-actions"><a href="{{ route('admin.siswa.edit') }}" class="btn primary">Edit</a><a href="{{ route('admin.siswa.index') }}" class="btn outline">Tutup</a></div></div>
@endsection
