@extends('layouts.admin')
@section('content')
<div class="admin-page-head"><div><h1>Data Siswa</h1><p>Dashboard / Data Siswa</p></div><a href="{{ route('admin.siswa.create') }}" class="btn primary">+ Tambah Siswa</a></div>
<div class="toolbar"><div class="search-bar"><i class="bi bi-search"></i><input placeholder="Cari siswa..."></div><select><option>Semua Kelas</option><option>X F 1</option><option>XI F 1</option><option>XII F 1</option></select></div>
<div class="admin-card table-card"><table><thead><tr><th>Siswa</th><th>NIS</th><th>Kelas</th><th>Status</th><th>Aksi</th></tr></thead><tbody>
@foreach(['RADEN MARDIANA','NADIA PUTRI','FARHAN AKBAR','ALYA NUR','RAKA ADITYA'] as $name)
<tr><td>{{ $name }}</td><td>12345678910</td><td>XII F 1</td><td><span class="badge success">Aktif</span></td><td class="actions"><a href="{{ route('admin.siswa.show') }}"><i class="bi bi-eye"></i></a><a href="{{ route('admin.siswa.edit') }}"><i class="bi bi-pencil"></i></a><button data-delete><i class="bi bi-trash"></i></button></td></tr>
@endforeach
</tbody></table>@include('components.pagination',['total'=>863])</div>
@endsection
