@extends('layouts.admin')
@section('content')
<div class="admin-page-head"><div><h1>Dashboard</h1><p>Ringkasan data website sekolah.</p></div></div>
<div class="stat-grid">
    @foreach([['Data Guru','42','bi-people-fill'],['Data Siswa','863','bi-person-lines-fill'],['Data Akun','2','bi-person-gear'],['Galeri','42','bi-images']] as $stat)
    <div class="stat-card"><div><i class="bi {{ $stat[2] }}"></i></div><span>{{ $stat[0] }}</span><strong>{{ $stat[1] }}</strong></div>
    @endforeach
</div>
<div class="dashboard-grid">
    <section class="admin-card chart-card"><div class="card-title"><h2>Statistik Siswa Perkelas</h2><span>Jumlah siswa</span></div>
        @foreach(['X F 1','X F 2','X F 3','X F 4','XI F 1','XI F 2','XI F 3','XII F 1','XII F 2'] as $class)
        <div class="bar-row"><label>{{ $class }}</label><div class="bar-track"><div class="bar" style="width: {{ rand(78,96) }}%"></div></div><b>{{ rand(34,38) }}</b></div>
        @endforeach
    </section>
    <section class="admin-card"><div class="card-title"><h2>Pengumuman Terbaru</h2><a href="{{ route('admin.pengumuman.index') }}">Lihat semua</a></div>
        @foreach(['JADWAL DCCB 15 JULI 2026','JADWAL DCCB 14 JULI 2026','JADWAL DCCB 13 JULI 2026','Pengumuman Seleksi SPMB 2026'] as $item)
        <div class="recent-item"><i class="bi bi-file-earmark-text-fill"></i><div><strong>{{ $item }}</strong><small>15 Jul 2026</small></div></div>
        @endforeach
    </section>
</div>
@endsection
