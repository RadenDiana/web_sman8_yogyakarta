@extends('layouts.admin')
@section('content')
<div class="admin-page-head"><div><h1>Ekstrakurikuler</h1><p>Dashboard / Ekstrakurikuler</p></div><a href="{{ route('admin.ekstrakurikuler.create') }}" class="btn primary">+ Ekstrakurikuler</a></div>
<div class="count-label">Total Ekstrakurikuler : <strong>27</strong></div>
<div class="extra-grid">
@foreach(['English Study Club','Teater','Bulu Tangkis','Tenis Meja','Basket','Pramuka','Petanque','Cheerleaders','Entrepreneurship','Fotografi dan Sinematografi','Tahfiz Quran','Flag Football','Hadroh','Bahasa Jerman','Seni Membaca Al-Quran','Pencak Silat','Orkestra','Paduan Suara','Debat Bahasa Inggris dan Indonesia','KIR'] as $item)
<div class="extra-card"><span>{{ $item }}</span><div><a href="{{ route('admin.ekstrakurikuler.edit') }}"><i class="bi bi-pencil"></i></a><button data-delete><i class="bi bi-trash"></i></button></div></div>
@endforeach
</div>
@include('components.pagination',['total'=>27])
@endsection
