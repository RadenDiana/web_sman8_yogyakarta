@extends('layouts.admin')
@section('content')
<div class="admin-page-head"><div><h1>Edit Ekstrakurikuler</h1><p>Dashboard / Ekstrakurikuler</p></div></div>
<form class="admin-card form-card narrow-form" onsubmit="demoSubmit(event,'Ekstrakurikuler berhasil disimpan!')">
<label>Nama Ekstrakurikuler<input required value="{{ $mode ?? '' }}"></label>
<div class="form-actions"><a href="{{ route('admin.ekstrakurikuler.index') }}" class="btn outline">Batal</a><button class="btn primary">Simpan</button></div>
</form>
@endsection
